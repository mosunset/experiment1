public interface Member {
    public void skill(Character c);
}
