public class Hero extends Ally {
    public Hero(String name, int hp, int atk) {
        super(name, hp, atk);
    }
}
