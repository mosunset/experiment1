//-*- coding: utf-8 -*-
public class Lesson02_1 {
    public static void main(String args[]) {
	// 必要な変数を定義
	
	
	// 定義した変数を用いて出力を行う
	System.out.println("Name: ");
	System.out.println("Age: ");
	System.out.println("Height: ");
	System.out.println("Birth day: ");
    }
}
