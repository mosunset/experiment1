//-*- coding: utf-8 -*-
public class Lesson02_2 {
    public static void main(String args[]) {
	int a = ; // １つ目の引数を変数aに格納
	int b = ; // ２つ目の引数を変数bに格納
	System.out.println(); // 面積を計算して出力
    }
}
