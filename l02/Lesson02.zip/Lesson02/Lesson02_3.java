//-*- coding: utf-8 -*-
public class Lesson02_3 {
    public static void main(String args[]){
	int n = ; // ランダムな値を取得 
	
	System.out.println("n = " + n); // nの値を出力
	
	// nの値に応じた処理を行う
	
    }
}
