//-*- coding: utf-8 -*-
public class Lesson02_4 {
    public static void main(String args[]) {
	String name = args[0]; // 引数を取得
	
	// nameに応じた処理を追加する
	
    }
}
