public class Lesson05_2 {
    public static void main(String[] args) {
        int input = Integer.parseInt(args[0]);//高さ
        // Add here==========================

        // =========================================
    }
}
