public class Lesson05_4 {
	public static void main(String[] args) {
		switch (args[0]) {
			// Add here==========================

			// =========================================
		}
	}
}
