public class Lesson05_5 {
    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);// 残ってる石の数
        int playerID = 1;// playerを入れ替えるための引数
        java.util.Scanner scan = new java.util.Scanner(System.in);
        while (true) {
            System.out.print("player" + playerID + " ... " + n + " >>> ");
            // Add here==========================
            
            // =========================================
        }
    }
}
