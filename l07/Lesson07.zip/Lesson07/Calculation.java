public class Calculation{
    int number;

    //add here
    
}
