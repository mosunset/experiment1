public class Lesson07_1{
    public static void main(String[] args){
        //add here        

    }
}