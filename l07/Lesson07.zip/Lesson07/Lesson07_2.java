public class Lesson07_2{
    public static void main(String[] args){
        Num n = new Num();
        n.mul(5, 9);
        n.mul(20, 0);
        n.div(10, 3);
        n.div(10, 0);
        n.mod(15, 7);
        n.mod(15, 0);
    }
}