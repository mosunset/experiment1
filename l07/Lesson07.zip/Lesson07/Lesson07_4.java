public class Lesson07_4{
    public static void main(String[] args){
        double radius = Double.parseDouble(args[0]);

        //add here
        
    }    
}
