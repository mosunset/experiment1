public class Lesson07_5{
    public static void main(String[] args){
        int[] even = {0, 2, 4, 6, 8, 10};
        int[] odd = {1, 3, 5, 7, 9, 11};

        //add here
    }    
}
