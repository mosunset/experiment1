class Num{
    void add(int num1, int num2){
        int add_num = num1 + num2;
        System.out.println(num1 + " + " + num2 + " = " + add_num);
    }
}