public class Sphere{
    double radius;
    
    //add here
}
