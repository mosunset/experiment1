public class Lesson03_1 {
    public static void main(String[] args) {
        int[] array = {10, 20, 30, 40, 50};

        /* -----ここから追加----- */
        
        
        /* -----ここまで追加----- */
    }

}