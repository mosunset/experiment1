public class Lesson03_2 {
    public static void main(String[] args) {
        System.out.println(mul(2, 4));
        System.out.println(mul(2, 4, 10));
        System.out.println(mul(2, 4, 10.0));
    }
    
    /* -----ここから追加----- */
    
    
    /* -----ここまで追加----- */
}