public class Lesson03_4 {
    public static void main(String[] args) {
        int[][] timeTable = new int[9][9];

        /* -----ここから追加----- */
        
        
        /* -----ここまで追加----- */

        //以下はtimeTableを用いて九九表を作成できているかを
        //確認するためのものであり、消さないこと
        System.out.println();
        System.out.println("---以下確認用---");
        System.out.println("2 * 4 = " + timeTable[1][3]);
        System.out.println("6 * 8 = " + timeTable[5][7]);
    }

}