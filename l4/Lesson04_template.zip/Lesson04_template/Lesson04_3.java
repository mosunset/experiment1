public class Lesson04_3 {
    public static void main(String[] args){
        System.out.print("整数を入力してください >> ");
        int n = new java.util.Scanner(System.in).nextInt();

        // add here
	
    }
}
