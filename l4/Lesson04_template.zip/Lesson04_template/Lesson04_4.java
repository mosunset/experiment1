public class Lesson04_4 {
    public static boolean isPrime(int n){
        // add here
       
    }
    
    public static void main(String[] args){
         System.out.print("整数を入力してください >> ");
        int n = new java.util.Scanner(System.in).nextInt();
        if(isPrime(n)){
            System.out.println(n + " は素数です");
        }else{
            System.out.println(n + " は素数ではありません");
        }
    }
}
