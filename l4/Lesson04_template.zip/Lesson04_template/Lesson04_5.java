public class Lesson04_5 {
    public static boolean isPrime(int n){
        // add here
      
    }

    public static int countPrime(int upper){
        // add here

        
    }

    public static void printAll(int upper){
	// add here
	
    }

    public static void main(String[] args){
        System.out.print("整数を入力してください >> ");
        int n = new java.util.Scanner(System.in).nextInt();
        System.out.println(n + " 以下に素数は " + countPrime(n) + " 個あります");
	printAll(n);
    }
}
