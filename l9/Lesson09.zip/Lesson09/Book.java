class Book {
	private String title;
	private String author;
	private int price;
	
	Book(String title, String author, int price) {
		this.title = title;
		this.author = author;
		this.price = price;
	}
}
