public class Lesson09_1 {
	public static void main(String[] args) {
		Student s = new Student();
		System.out.println("Name: " + s.name);
		System.out.println("Age: " + s.age);
		System.out.println("Birthday: " + s.year + "/" + s.month + "/" + s.day);
	}
}