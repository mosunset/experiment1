public class Lesson09_3 {
	public static void main(String[] args) {
		Teacher t = new Teacher();

		// Add here
		
	}
}
