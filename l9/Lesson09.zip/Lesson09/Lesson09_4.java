public class Lesson09_4 {
	public static void main(String[] args) {
		Book book1 = new Book("スッキリわかるJava 入門", "中山清喬", 3500);
		// Add here - 1冊目の表示


		Book book2 = new Book("入門bash", "キャメロン・ニューハム", 3000);
		// Add here - 2冊目の表示 & インスタンス数の出力


		Book book3 = new Book("詳解シェルスクリプト", "ネルソン・H.f.ベーブ", 3200);
		// Add here - 3冊目の表示 & インスタンス数の出力

		
	}
}
