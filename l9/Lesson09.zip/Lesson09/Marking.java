class Marking {
	private int score[] = new int[10];
	//環境によって違う配列の初期値を統一する目的で初期化を行う. 配列の初期値は0とする.
	// Add here
}
