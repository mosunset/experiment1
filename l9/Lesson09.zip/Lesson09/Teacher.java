class Teacher {
	private String name;
	private String lab;

	// Add here
}
